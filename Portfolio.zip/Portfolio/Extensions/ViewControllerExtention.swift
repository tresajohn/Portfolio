//
//  ViewControllerExtention.swift
//  Portfolio
//
//  Created on 07/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {

    //create navigation bar button
    func createNavigationBarButtonLeft()
    {
        let navigationButtonName = UIButton()
        navigationButtonName.setImage(UIImage(named: "ic_home.png"), for: UIControlState())
        navigationButtonName.frame = CGRect(x: 0, y: 0, width: 30, height: 30)        
        
        let leftBarButton = UIBarButtonItem()
        leftBarButton.customView = navigationButtonName
        self.navigationItem.leftBarButtonItem = leftBarButton
    }
    
    func shareApp()
    {
        let shareText = "Use this App!"
        let actionSheet = UIActivityViewController(activityItems: [shareText], applicationActivities: [])
        present(actionSheet, animated: true, completion: nil)
    }
    
    //Create Share Button
    func createShareButtonRight()
    {
        let shareButtonName = UIButton()
        shareButtonName.setImage(UIImage(named: "ic_share_icon.png"), for: UIControlState())
        shareButtonName.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        shareButtonName.addTarget(self, action: #selector(UIViewController.shareApp), for: .touchUpInside)
        
        let leftBarButton = UIBarButtonItem()
        leftBarButton.customView = shareButtonName
        self.navigationItem.rightBarButtonItem = leftBarButton
    }
    
    func createLogoutButton()
    {
        let logoutButton = UIButton()
        logoutButton.setImage(UIImage(named: "ic_logout.png"), for: UIControlState())
        logoutButton.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        logoutButton.addTarget(self, action: #selector(UIViewController.logOut), for: .touchUpInside)
        
        let leftBarButton = UIBarButtonItem()
        leftBarButton.customView = logoutButton
        self.navigationItem.leftBarButtonItem = leftBarButton
    }
    
    func logOut()
    {
        self.dismiss(animated: false, completion: nil)
    }
    
    //Calls this function when the tap is recognized.
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }
}
