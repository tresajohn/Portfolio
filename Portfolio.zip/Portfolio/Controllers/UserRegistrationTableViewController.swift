//
//  UserRegistrationTableViewController.swift
//  Portfolio
//
//  Created on 07/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class UserRegistrationTableViewController: UITableViewController, UIPickerViewDelegate, UIPickerViewDataSource{

    //User Registrartion Input fields
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var countryTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var dobTextField: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var conPasswordTextField: UITextField!
    
    //User Registration
    var registerUser = [String : String]()
    
    //DatePicker
    var dobDatePicker: UIDatePicker = UIDatePicker()
    var dobFormatter : DateFormatter?
    var selectedCountry : String?    
    
    //Toolbars
    let dateToolBar = UIToolbar()
    let countryToolBar = UIToolbar()
    
    //County List
    var countryNames : [String]?
    
    //Country Picker
    var countryNamePicker: UIPickerView = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Registration"
        
        //Default User Details
        registerUser = ["name":"Tresa", "country":"India", "age":"32", "dob":"16-01-1985", "mobile":"9946112170", "email":"tresajohn@gmail.com", "password":"12345678", "confirmPassword":"12345678"]
        tableView.backgroundView = UIImageView(image: UIImage(named: "ic_app_background.jpg"))
        
        //Hide keyPad when tap Outside
        self.hideKeyboardWhenTappedAround()
        
        //Date Picker for DOB
        dobDatePicker = UIDatePicker(frame:CGRect(x: 0, y: 50, width: self.view.frame.width, height: 200))
        dobDatePicker.timeZone = TimeZone.autoupdatingCurrent
        dobDatePicker.backgroundColor = UIColor.white
        dobDatePicker.layer.cornerRadius = 5.0
        dobDatePicker.layer.shadowOpacity = 0.5
        dobDatePicker.datePickerMode = UIDatePickerMode.date
        dobDatePicker.maximumDate = Date()
        
        //toolbar
        dateToolBar.barStyle = UIBarStyle.default
        dateToolBar.isTranslucent = true
        dateToolBar.tintColor = UIColor.black
        dateToolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(UserRegistrationTableViewController.doneDatePicker))
        
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action: #selector(UserRegistrationTableViewController.cancelDatePicker))
        
        dateToolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
        dateToolBar.isUserInteractionEnabled = true
        dobTextField.inputView = dobDatePicker
        dobTextField.inputAccessoryView = dateToolBar
        
        
        //Country Name Picker
        let locale = Locale.current
        let countryArray = Locale.isoRegionCodes
        let unsortedCountryArray:[String] = countryArray.map { (countryCode) -> String in
            return (locale as NSLocale).displayName(forKey: NSLocale.Key.countryCode, value: countryCode)!
        }
        countryNames = unsortedCountryArray.sorted()
        countryNamePicker = UIPickerView(frame:CGRect(x: 0, y: 50, width: UIScreen.main.bounds.width, height: 200))
        countryNamePicker.backgroundColor = UIColor.white
        countryNamePicker.layer.cornerRadius = 5.0
        countryNamePicker.layer.shadowOpacity = 0.5
        
        //Assign Delegate & Data Source as "self"
        countryNamePicker.dataSource = self
        countryNamePicker.delegate = self
        
        let countryCancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItemStyle.plain, target: self, action: #selector(UserRegistrationTableViewController.cancelCountryPicker))
        let countrySpaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.flexibleSpace, target: nil, action: nil)
        let countryDoneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.plain, target: self, action: #selector(UserRegistrationTableViewController.doneCountryPicker))
        
        //CountryToolBar
        countryToolBar.setItems([countryCancelButton, countrySpaceButton, countryDoneButton], animated: false)
        countryToolBar.isUserInteractionEnabled = true
        countryToolBar.tintColor = UIColor.black
        countryToolBar.sizeToFit()
        countryTextField.inputView = countryNamePicker
        countryTextField.inputAccessoryView = countryToolBar
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countryNames!.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedCountry = countryNames?[row] as String?
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return countryNames?[row]
    }
    
    func doneDatePicker(_ sender: UIButton!)
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
        dobTextField.text = dateFormatter.string(from: dobDatePicker.date)
        dobTextField.resignFirstResponder()
        
    }
    
    func cancelDatePicker(_ sender: UIButton!)
    {
        dobTextField.resignFirstResponder()
    }
    
    func doneCountryPicker(_ sender: UIButton!)
    {
        if(selectedCountry != nil)
        {
            countryTextField.text = selectedCountry!
            countryTextField.resignFirstResponder()
        }
    }
    
    func cancelCountryPicker(_ sender: UIButton)
    {
        countryTextField.resignFirstResponder()
    }
    
    
    func showAlert(_ message : String)
    {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
    
    //validate phone
    func ValidateMobile(_ phone : String) ->Bool
    {
        if phone.characters.count == 10
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    //validate email
    func ValidateEmail(_ Email : String) ->Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        if emailTest.evaluate(with: Email) == true
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    //validate age
    func ValidateAge(_ Age : String) ->Bool
    {
        if Int(Age) == nil
        {
            return false
        }
        else
        {
            return true
        }
    }
    
    @IBAction func registerUserButtonAction(_ sender: UIButton) {
        //User Registration Inputs & Validation
        registerUser["name"] = nameTextField.text
        registerUser["country"] = countryTextField.text
        registerUser["age"] = ageTextField.text
        registerUser["dob"] = dobTextField.text
        registerUser["mobile"] = mobileTextField.text
        registerUser["email"] = emailTextField.text
        registerUser["password"] = passwordTextField.text
        registerUser["confirmPassword"] = conPasswordTextField.text
        
        //Check blank (whiteSpace) input
        let whiteSpace = CharacterSet.whitespaces
        guard(registerUser["name"]?.isEmpty != true && registerUser["country"]?.isEmpty != true && registerUser["age"]?.isEmpty != true && registerUser["dob"]?.isEmpty != true && registerUser["mobile"]?.isEmpty != true && registerUser["email"]?.isEmpty != true && registerUser["password"]?.isEmpty != true && registerUser["confirmPassword"]?.isEmpty != true) else{
            
            return self.showAlert("Input Should not be Empty")
        }
        //Check blank Spaces
        guard(registerUser["name"]?.trimmingCharacters(in: whiteSpace).isEmpty != true &&  registerUser["country"]?.trimmingCharacters(in: whiteSpace).isEmpty != true && registerUser["age"]?.trimmingCharacters(in: whiteSpace).isEmpty != true && registerUser["dob"]?.trimmingCharacters(in: whiteSpace).isEmpty != true && registerUser["mobile"]?.trimmingCharacters(in: whiteSpace).isEmpty != true && registerUser["email"]?.trimmingCharacters(in: whiteSpace).isEmpty != true && registerUser["password"]?.trimmingCharacters(in: whiteSpace).isEmpty != true && registerUser["confirmPassword"]?.trimmingCharacters(in: whiteSpace).isEmpty != true) else {
            
            return self.showAlert("Input Should not be Blank")
        }
        
        //Validate age
        guard(self.ValidateAge(registerUser["age"]!) == true)
            else{
                return self.showAlert("Invalid Age")
        }
        
        //Validate mobile
        guard(self.ValidateMobile(registerUser["mobile"]!) == true)
            else{
                return self.showAlert("Invalid mobile number")
        }
        
        //Validate email
        guard(self.ValidateEmail(registerUser["email"]!) == true)
            else{
                return self.showAlert("Invalid Email ID")
        }
        
        //CheckPassword
        guard((registerUser["password"]!.characters.count) >= 8 && (registerUser["confirmPassword"]!.characters.count) >= 8)
            else{
                return self.showAlert("Minimum password length is 8 characters")
        }
        
        //Check Password Matching
        guard(registerUser["password"] == registerUser["confirmPassword"])
            else{
                return self.showAlert("Password and Confirm password should be same")
        }        
        
        //Registration Success
        let loginViewControllerObj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginVCID")as? LoginViewController
        loginViewControllerObj?.registeredEmail = registerUser["email"]
        loginViewControllerObj?.registeredPassword = registerUser["password"]
        loginViewControllerObj?.userDetailsDictinary = registerUser
        navigationController?.pushViewController(loginViewControllerObj!, animated: true)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "displaySegue")
        {
            //Direct Login
            let loginViewControllerSegueObj = segue.destination as? LoginViewController
            loginViewControllerSegueObj?.registeredEmail = registerUser["email"]
            loginViewControllerSegueObj?.registeredPassword = registerUser["password"]
            loginViewControllerSegueObj?.userDetailsDictinary = registerUser
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
