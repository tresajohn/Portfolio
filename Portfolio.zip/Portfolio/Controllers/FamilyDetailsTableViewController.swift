//
//  FamilyDetailsTableViewController.swift
//  Portfolio
//
//  Created on 08/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class FamilyDetailsTableViewController: UITableViewController {

    var familyTableSections :[String] = ["Parents", "Siblings"]
    var familyMembersName : [[String]] = [["John", "Rose"], ["Rigil", "Tresa"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Family Details"
        tableView.backgroundView = UIImageView(image: UIImage(named: "ic_app_background.jpg"))
        createShareButtonRight()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return familyTableSections.count
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return familyMembersName[section].count
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let returnedView = UIView(frame: CGRect(x: 0, y: 0,width: tableView.frame.width, height: 25))
        returnedView.backgroundColor = UIColor.clear
        let label = UILabel(frame: CGRect(x: 2 , y: 2, width: tableView.frame.width, height: 25))
        label.textColor = UIColor(red: 51/255, green: 153/255, blue: 255/255, alpha: 0.7)
        label.font = UIFont.boldSystemFont(ofSize: 25)
        label.text = familyTableSections[section]
        returnedView.addSubview(label)
        return returnedView
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return familyTableSections[section]
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tableCell = tableView.dequeueReusableCell(withIdentifier: "familyMembersTableCell", for: indexPath)
        tableCell.backgroundColor = UIColor.clear
        tableCell.selectionStyle = .none
        tableView.separatorStyle = .none
        tableCell.textLabel?.text = familyMembersName[indexPath.section][indexPath.row]
        return tableCell
    }
}
