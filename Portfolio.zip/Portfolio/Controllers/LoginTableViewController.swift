//
//  LoginTableViewController.swift
//  Portfolio
//
//  Created on 07/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class LoginTableViewController: UITableViewController, UITextFieldDelegate {

    @IBOutlet weak var loginEmailTextField: UITextField!
    @IBOutlet weak var loginPasswordTextField: UITextField!    
    var loginDictionary : [String:String]  = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.backgroundView = UIImageView(image: UIImage(named:"ic_app_background.jpg"))
        loginEmailTextField.text = "tresajohn@gmail.com"
        loginPasswordTextField.text = "12345678"
    }
    
    func getLoginDetails()
    {
        loginDictionary["email"] = loginEmailTextField.text
        loginDictionary["password"] = loginPasswordTextField.text
        
    }
}
