//
//  ScreensTabBarController.swift
//  Portfolio
//
//  Created on 07/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class ScreensTabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }    
}
