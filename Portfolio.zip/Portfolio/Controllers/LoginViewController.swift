//
//  LoginViewController.swift
//  Portfolio
//
//  Created on 07/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    var registeredEmail : String?
    var registeredPassword : String?
    var loginEmail : String?
    var loginPassword : String?
    var userDetailsDictinary = [String : String]()    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "ic_app_background.jpg")!)
        title = "Login"
        self.hideKeyboardWhenTappedAround()
    }
    
    //validate email
    func ValidateEmail(_ Email : String) ->Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        if emailTest.evaluate(with: Email) == true
        {
            return true
        }
        else
        {
            return false
        }
    }
    
    //Error Alert Dialog
    func showAlert(_ message : String)
    {
        let alertController = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
        
    }
    
    @IBAction func loginButtonAction(_ sender: UIButton) {
        
        let loginViewControllerObj = self.childViewControllers.first as? LoginTableViewController
        loginViewControllerObj?.getLoginDetails()
        let loginDictionary = loginViewControllerObj?.loginDictionary
        self.loginEmail = loginDictionary!["email"]
        self.loginPassword = loginDictionary!["password"]
        
        //Check for empty/Null inputs
        guard(self.loginEmail!.isEmpty != true && self.loginPassword!.isEmpty != true)else{
            return self.showAlert("Email & Password should not be Empty")
        }
        
        //Check blank (whiteSpace) input
        let whiteSpace = CharacterSet.whitespaces
        
        guard(self.loginEmail!.trimmingCharacters(in: whiteSpace).isEmpty != true && self.loginPassword!.trimmingCharacters(in: whiteSpace).isEmpty != true)else{
            return self.showAlert("Email & Password should not be Blank")
        }
        
        //Validate email
        guard(self.ValidateEmail(loginEmail!) == true)
            else{
                return self.showAlert("Invalid Email ID")
        }
        
        guard((self.loginEmail! == self.registeredEmail!) && (self.loginPassword! == self.registeredPassword!))else{
            
            //Invalid username-password combination
            return self.showAlert("Invalid Login!")
        }
        
        //Login Success (Store datas & proceed)
        let userDetails = UserDefaults.standard
        userDetails.set(userDetailsDictinary["name"], forKey: "name")
        userDetails.set(userDetailsDictinary["email"], forKey: "email")
        userDetails.set(userDetailsDictinary["phone"], forKey:"phone")
        userDetails.set(userDetailsDictinary["dob"], forKey: "dob")
        userDetails.set(userDetailsDictinary["country"], forKey: "country")
        userDetails.set(userDetailsDictinary["age"], forKey: "age")
        
        //Registration Success
        let homeScreenViewControllerObj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "homeScreenVCID")as? ScreensTabBarController
        navigationController?.present(homeScreenViewControllerObj!, animated: true, completion:nil)
    }
}
