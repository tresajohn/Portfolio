//
//  ProfileDetailsTableViewController.swift
//  Portfolio
//
//  Created on 08/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class ProfileDetailsTableViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var bloodGroupLabel: UILabel!
    @IBOutlet weak var addressTextView: UITextView!
    @IBOutlet weak var address2TextView: UITextView!
    @IBOutlet weak var panLabel: UILabel!
    @IBOutlet weak var membersLabel: UILabel!
    @IBOutlet weak var profileImageView: UIImageView!
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Profile"
        tableView.backgroundView = UIImageView(image: UIImage(named: "ic_app_background.jpg"))
        
        //set Image view radius
        self.profileImageView.layer.cornerRadius = 85
        self.profileImageView.layer.masksToBounds = true
        
        imagePicker.delegate = self
        
        //Share button
        createShareButtonRight()
        createLogoutButton()
        
        //Retrive Data from User Default
        let userDetails = UserDefaults.standard
        if let name = userDetails.string(forKey: "name")
        {
            nameLabel.text = name
        }
    }
    
    //View Family Details
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
        if indexPath.row == 2
        {
            //Registration Success
            let familyTableViewControllerObj = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "familyDetailsTVCID")as? FamilyDetailsTableViewController
            navigationController?.pushViewController(familyTableViewControllerObj!, animated: true)
        }
    }    
    
    func imageFromLibrary()
    {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary)
        {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
            imagePicker.allowsEditing = true
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    //Take photo using camera
    func imageFromCamera()
    {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
            let imagePicker = UIImagePickerController()
            imagePicker.delegate = self
            imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
            imagePicker.allowsEditing = false
            self.present(imagePicker, animated: true, completion: nil)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let pickerImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            profileImageView.image = pickerImage
            if picker.sourceType == .camera {
                UIImageWriteToSavedPhotosAlbum(pickerImage, nil, nil, nil)
            }
        }
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func changePhotoButtonAction(_ sender: AnyObject) {
        let optionMenu = UIAlertController(title: nil, message: "Choose Option", preferredStyle: .actionSheet)
        //Select Image from Gallery
        let library = UIAlertAction(title: "Select From Library", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.imageFromLibrary()
        })
        //Open Camera & take Photo
        let camera = UIAlertAction(title: "Take a Picture", style: .default, handler: {
            (alert: UIAlertAction!) -> Void in
            self.imageFromCamera()
        })
        //Cancel action
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: {
            (alert: UIAlertAction!) -> Void in
        })
        
        optionMenu.addAction(library)
        optionMenu.addAction(camera)
        optionMenu.addAction(cancelAction)
        self.present(optionMenu, animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
