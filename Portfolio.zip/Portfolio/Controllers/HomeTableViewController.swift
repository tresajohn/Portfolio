//
//  HomeTableViewController.swift
//  Portfolio
//
//  Created on 08/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class HomeTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Home"
        tableView.backgroundView = UIImageView(image: UIImage(named:"ic_app_background.jpg"))
                
        //Share button
        createShareButtonRight()
        createLogoutButton()
    }
    
    @IBAction func buttonOpenWeb(_ sender: UIButton) {
        
        UIApplication.shared.openURL(URL(string: "http://google.com/")!)
    }
    
    @IBAction func buttonDial(_ sender: UIButton) {
        UIApplication.shared.openURL(URL(string: "telprompt://9946112170")!)
    }
}
