//
//  AddSignatureViewController.swift
//  Portfolio
//
//  Created by focaloid on 09/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class AddSignatureViewController: UIViewController {

    var lastPoint:CGPoint!
    var isSwiping:Bool!
    var red:CGFloat!
    var green:CGFloat!
    var blue:CGFloat!
    
    @IBOutlet weak var signatureImageView: UIImageView!    
    @IBOutlet weak var signhereLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        red   = (0.0/255.0)
        green = (0.0/255.0)
        blue  = (0.0/255.0)
        
        title = "Add Signature"
        //self.view.backgroundColor = UIColor(patternImage: UIImage(named: "ic_app_background.jpg")!)
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "ic_app_background.jpg")
        self.view.insertSubview(backgroundImage, at: 0)
        
        //Share button
        createShareButtonRight()
        createLogoutButton()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        isSwiping    = false
        if let touch =  touches.first{
            
            lastPoint = touch.location(in: signatureImageView)
            signhereLabel.text = .none
        }
        super.touchesBegan(touches, with: event)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if(!isSwiping) {
            UIGraphicsBeginImageContext(self.signatureImageView.frame.size)
            self.signatureImageView.image?.draw(in: CGRect(x: 0, y: 0, width: self.signatureImageView.frame.size.width, height: self.signatureImageView.frame.size.height))
            UIGraphicsGetCurrentContext()?.setLineCap(CGLineCap.round)
            UIGraphicsGetCurrentContext()?.setLineWidth(9.0)
            UIGraphicsGetCurrentContext()?.setStrokeColor(red: red, green: green, blue: blue, alpha: 1.0)
            UIGraphicsGetCurrentContext()?.move(to: CGPoint(x: lastPoint.x, y: lastPoint.y))
            UIGraphicsGetCurrentContext()?.addLine(to: CGPoint(x: lastPoint.x, y: lastPoint.y))
            UIGraphicsGetCurrentContext()?.strokePath()
            self.signatureImageView.image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        isSwiping = true
        if let touch = touches.first{
            let currentPoint = touch.location(in: signatureImageView)
            UIGraphicsBeginImageContext(self.signatureImageView.frame.size)
            self.signatureImageView.image?.draw(in: CGRect(x: 0, y: 0, width: self.signatureImageView.frame.size.width, height: self.signatureImageView.frame.size.height))
            UIGraphicsGetCurrentContext()?.move(to: CGPoint(x: lastPoint.x, y: lastPoint.y))
            UIGraphicsGetCurrentContext()?.addLine(to: CGPoint(x: currentPoint.x, y: currentPoint.y))
            UIGraphicsGetCurrentContext()?.setLineCap(CGLineCap.round)
            UIGraphicsGetCurrentContext()?.setLineWidth(9.0)
            UIGraphicsGetCurrentContext()?.setStrokeColor(red: red, green: green, blue: blue, alpha: 1.0)
            UIGraphicsGetCurrentContext()?.strokePath()
            self.signatureImageView.image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            lastPoint = currentPoint
        }
        super.touchesMoved(touches, with: event)
    }

    @IBAction func cancelSignatureAction(_ sender: AnyObject) {
        self.signatureImageView.image = nil
        signhereLabel.text = "Sign here"
    }

    @IBAction func saveSignatureAction(_ sender: AnyObject) {
        if self.signatureImageView.image == nil{
            return
        }
        UIImageWriteToSavedPhotosAlbum(self.signatureImageView.image!,self, #selector(AddSignatureViewController.image(_:withPotentialError:contextInfo:)), nil)
    }
    
    func image(_ image: UIImage, withPotentialError error: NSErrorPointer, contextInfo: UnsafeRawPointer) {
        let alert = UIAlertController(title: nil, message: "Image successfully saved to Photos library", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { action in
        })
        self.present(alert, animated: true, completion: nil)
    }
}
