//
//  PDFViewerViewController.swift
//  Portfolio
//
//  Created on 13/12/16.
//  Copyright © 2016 Focaloid. All rights reserved.
//

import UIKit

class PDFViewerViewController: UIViewController {

    @IBOutlet weak var pdfWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor(patternImage: UIImage(named: "ic_app_background.jpg")!)
        title = "Resume"
        
        let pdfPath = Bundle.main.path(forResource: "Resume_TresaJohn.pdf", ofType:nil)
        let url = URL(fileURLWithPath: pdfPath!)
        let request = URLRequest(url: url)        
        pdfWebView.loadRequest(request)
        
        //Share button
        createShareButtonRight()
        createLogoutButton()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
